$(function(){

    function time(){
     var date = new Date();
     console.log(date);
     var hour = date.getHours();
     var min =  date.getMinutes();
     var sec = date.getSeconds();
     var msec = date.getMilliseconds();
     msec = Math.floor(msec/10);
        // 자리수를 2자리로 만들어 주는 함수
     function digit(n){

        if(n<10){
            n = "0" + n;
            return n;

        }else{
            return n;
        }
     }

    var newHour = digit(hour);
    var newMin = digit(min);
    var newSec = digit(sec);
    var newMsec = digit(msec);

     $(".time .hour").text(newHour);
     $(".time .min").text(newMin);
     $(".time .sec").text(newSec);
     $(".time .msec").text(newMsec);

   }
   setInterval(function(){
    time()

   },10)









});