$(function(){

    $('.familly').click(function(){
        $('.fam_list').toggle();
    })

    $('.fam_company').click(function(){
        $('.com_list').toggle();
    })
})