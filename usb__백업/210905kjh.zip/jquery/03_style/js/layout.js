$('hide').on(click, function(){
    $('')
})