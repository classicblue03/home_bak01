$(function(){
    $('.btn_family').click(
        function(){
            //alert("click");
            //$(this).next().toggle();
            $('.list').toggle();
        }
    )

    $('.list li a').click(
        function(){

        }
    )


})